﻿(function () {
    'use strict';

    var movieApp = angular.module('app');
    movieApp.controller('NewMovieController', NewMovieController);
    NewMovieController.$inject = ['DataService'];

    function NewMovieController(DataService) {
        var vm = this;
        vm.title = 'Add New Movie';
        vm.success = false;
        vm.newMovie = {};

        vm.languages = [{
            id: 'English',
            name: 'English'
        },
        {
            id: 'Sinhala',
            name: 'Sinhala'
        },
        {
            id: 'Hindi',
            name: 'Hindi'
        },
        {
            id: 'Korean',
            name: 'Korean'
        }
        ];

        vm.movieCharacters = [];

        vm.submitMovie = function () {
            var maxId = DataService.getLastMovieId();

            if (maxId >= 0) {
                vm.newMovie.id = maxId + 1;
            }
            DataService.setMovie({
                id: vm.newMovie.id,
                title: vm.newMovie.title,
                description: vm.newMovie.description,
                director: vm.newMovie.director,
                releaseYear: vm.newMovie.year,
                rating: vm.newMovie.rating,
                language: vm.newMovie.language
            });
            vm.mode = 'success';
            vm.success = true;
            vm.showCharacters = true;
        };

        vm.submitChraracter = function () {
            DataService.setCharacter(vm.newMovie.id, {
                character: vm.newCharacter.character,
                actor: vm.newCharacter.actor
            });

            vm.getMovieCharacters();
        };

        vm.getMovieCharacters = function () {
            vm.movieCharacters = DataService.getCharacters(vm.newMovie.id);
        };
    }
})();