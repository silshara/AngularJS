﻿(function () {
    'use strict';

    var app = angular.module('app', ['ui.router', 'ngStorage']);
    app.controller('MainController', MainController);

    function MainController($state) {
        var vm = this;
        vm.title = 'My Movies';
        $state.go('movies');
    }
})();