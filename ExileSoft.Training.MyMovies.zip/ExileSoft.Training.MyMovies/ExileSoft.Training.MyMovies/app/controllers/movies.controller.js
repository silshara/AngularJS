﻿(function () {
    'use strict';

    var movieApp = angular.module('app');
    movieApp.controller('MovieController', MovieController);

    function MovieController(DataService) {
        var vm = this;

        vm.movies = [];
        vm.class = 'list-group-item';
        vm.DisplayModeEnum = {
            Grid: 0,
            List: 1
        };

        vm.changeDisplayMode = function (displayMode) {
            switch (displayMode) {
                case vm.DisplayModeEnum.Grid:
                    vm.class = 'grid-group-item';
                    break;
                case vm.DisplayModeEnum.List:
                    vm.class = 'list-group-item';
                    break;
            }
        };

        function init() {
            getMoviesSummary();
        }

        function getMoviesSummary() {
            vm.movies = DataService.getMovies();
        }

        init();
    }
})();