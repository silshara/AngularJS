﻿(function () {
    'use strict';

    var movieApp = angular.module('app');
    movieApp.controller('MovieDetailsController', MovieDetailsController);

    function MovieDetailsController(DataService, $state, $stateParams) {
        var vm = this;
        var id = $stateParams.movieId;

        var moviesById = DataService.getMovieById(id);
        if (moviesById.length > 0) {
            vm.movie = moviesById[0];

            vm.movieCharacters = DataService.getCharacters(id);
        }
    }
})();