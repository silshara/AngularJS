﻿(function () {
    'use strict';

    var movieApp = angular.module('app');
    movieApp.config(routeConfig);

    function routeConfig($stateProvider) {
        $stateProvider.state('movies', {
            url: '/',
            templateUrl: '../views/movies.html',
            controller: 'MovieController as vm'
        }).state('addMovie', {
            url: '/addMovie',
            templateUrl: '../views/newMovie.html',
            controller: 'NewMovieController as vm'
        }).state('movieDetails', {
            url: '/movieDetails',
            templateUrl: '../views/movieDetails.html',
            controller: 'MovieDetailsController as vm',
            params: {
                movieId: 0
            }
        })
    }

})();