﻿(function () {
    'use strict';

    var app = angular.module('app');
    app.service('DataService', DataService);

    function DataService($localStorage) {
        var self = this;

        var movies = [
            {
                id: 1,
                title: 'The Dark Night',
                description: 'Batman raises the stakes in his war on crime. With the help of Lt. Jim Gordon and District Attorney Harvey Dent, Batman sets out to dismantle the remaining criminal organizations that plague the streets. The partnership proves to be effective, but they soon find themselves prey to a reign of chaos unleashed by a rising criminal mastermind known to the terrified citizens of Gotham as the Joker.',
                director: 'Christopher Nolan',
                releaseYear: 2008,
                rating: 6,
                language: 'English'

            },
            {
                id: 2,
                title: 'Dhanak',
                description: 'The orphan siblings, 10-year old Pari and 8-year old Chotu face various situations in life to restore Chotu\'s eyesight.',
                director: 'Nagesh Kukunoor',
                releaseYear: 2016,
                rating: 4,
                language: 'Hindi'
            },
            {
                id: 3,
                title: 'Ho Gaana Pokuna',
                description: 'Ho Gana Pokuna is a Sri Lankan children\'s Musical Movie directed by Indika Ferdinando. It was awarded the Teacher\'s Choice Prize at the 31st Chicago International Children\'s Film Festival.',
                director: 'Indika Ferdinando',
                releaseYear: 2014,
                rating: 8,
                language: 'Sinhala'
            },
            {
                id: 4,
                title: 'Rogue One: A Star Wars Story',
                description: 'Resistance fighters (Felicity Jones, Diego Luna) embark on a daring mission to steal the Empire\'s plans for the Death Star.',
                director: 'Gareth Edwards',
                releaseYear: 2016,
                rating: 5,
                language: 'English'
            }
            ,
            {
                id: 5,
                title: 'Chennai Express',
                description: 'A man\'s (Shahrukh Khan) trip to fulfill his late grandfather\'s last wish turns into an unexpected adventure when he meets a unique young woman (Deepika Padukone) from southern India.',
                director: 'Rohit Shetty',
                releaseYear: 2013,
                rating: 7,
                language: 'Hindi'
            }
        ];

        var movieCharacters = [
            {
                id: 1,
                characters: [
                    { character: "Bruce Wayne", actor: "Christian Bale" },
                    { character: "Joker", actor: "Heath Ledger" },
                    { character: "Rachel Dawes", actor: "Maggie Gyllenhaal" }]
            },
            {
                id: 2,
                characters: [
                    { character: "Chotu", actor: "Krrish Chhabria" },
                    { character: "Pari", actor: "Hetal Gada" }]
            },
            {
                id: 3,
                characters: [
                    { character: "Driver", actor: "Jayalath Manoratne" },
                    { character: "Teacher", actor: "Anasuya Subasinghe" },
                    { character: "Principal", actor: "Lucian Bulathsinhala" }                 
                ]
            },
            {
                id: 4,
                characters: [
                    { character: "Luke Skywalker", actor: "Mark Hamill" },
                    { character: "Princess Leia", actor: "Carrie Fisher" }
                ]
            },
            {
                id: 5,
                characters: [
                    { character: "Rahul", actor: "Shah Rukh Khan" },
                    { character: "Meenamma", actor: "Deepika Padukone" }
                ]
            }
        ];

        $localStorage = $localStorage.$default({
            movieData: movies,
            characterData: movieCharacters
        });

        self.getMovies = function () {
            return $localStorage.movieData;
        };

        self.setMovie = function (movie) {
            $localStorage.movieData.push(movie);
        };

        self.getLastMovieId = function () {
            return $localStorage.movieData.length;
        }

        self.getMovieById = function (movieId) {
            return $localStorage.movieData.filter(
                function (data) { return data.id == movieId }
            );
        };

        self.setCharacter = function (movieId, character) {
            var characterItems = self.getMovieCharacterbyId(movieId);
            if (characterItems.length > 0) {
                var index = $localStorage.characterData.indexOf(characterItems[0]);
                if (index >= 0) {
                    $localStorage.characterData[index].characters.push(character);
                }
                else {
                    $localStorage.characterData.push({
                        id: movieId,
                        characters: [character]
                    });
                }
            }
            else {
                $localStorage.characterData.push({
                    id: movieId,
                    characters: [character]
                });
            }
        };

        self.getCharacters = function (movieId) {
            var characterItems = self.getMovieCharacterbyId(movieId);

            if (characterItems.length > 0) {
                return characterItems[0].characters
            }
            else {
                return null;
            }
        };

        self.getMovieCharacterbyId = function (id) {
            return $localStorage.characterData.filter(
                function (data) { return data.id == id }
            );
        }
    }
})();